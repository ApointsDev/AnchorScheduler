import React, { useRef, useState, useCallback, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Send, Image, Mic, MicOff } from "lucide-react";
import { Button } from "../ui/Button";
import { Textarea } from "../ui/Textarea";
import "../../styles/ChatActionBar.css";

interface ChatActionBarProps {
    input: string;
    onInputChange: (value: string) => void;
    onSend: () => void;
    onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
    loading: boolean;
    /** 是否嵌入卡片内（PC 端），false 则透明背景适配浮动栏 */
    embedded?: boolean;
}

/* ── 语音识别 ────────────────────────────────── */
/* eslint-disable @typescript-eslint/no-explicit-any */
// @ts-ignore - SpeechRecognition not in standard lib
const SpeechRecognitionAPI: any =
    (window as any).SpeechRecognition ||
    (window as any).webkitSpeechRecognition;
/* eslint-enable @typescript-eslint/no-explicit-any */

const supportsVoice = !!SpeechRecognitionAPI;

const ChatActionBar: React.FC<ChatActionBarProps> = ({
    input,
    onInputChange,
    onSend,
    onFileUpload,
    loading,
    embedded = false,
}) => {
    const { t } = useTranslation();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [isRecording, setIsRecording] = useState(false);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const recognitionRef = useRef<any>(null);

    const stopRecording = useCallback(() => {
        if (recognitionRef.current) {
            recognitionRef.current.stop();
            recognitionRef.current = null;
        }
        setIsRecording(false);
    }, []);

    const toggleVoice = useCallback(() => {
        if (!supportsVoice) {
            alert("您的浏览器不支持语音输入，请使用 Chrome 或 Edge。");
            return;
        }

        if (isRecording) {
            stopRecording();
            return;
        }

        try {
            const recognition = new SpeechRecognitionAPI();
            recognition.lang = "zh-CN";
            recognition.interimResults = true;
            recognition.continuous = true;

            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            recognition.onresult = (event: any) => {
                let transcript = "";
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    transcript += event.results[i][0].transcript;
                }
                if (event.results[event.results.length - 1].isFinal) {
                    onInputChange(input + transcript);
                }
            };

            recognition.onerror = () => {
                stopRecording();
            };

            recognition.onend = () => {
                setIsRecording(false);
                recognitionRef.current = null;
            };

            recognitionRef.current = recognition;
            recognition.start();
            setIsRecording(true);
        } catch {
            alert("无法启动语音输入，请检查麦克风权限。");
        }
    }, [isRecording, stopRecording, onInputChange, input]);

    useEffect(() => {
        return () => {
            if (recognitionRef.current) {
                recognitionRef.current.stop();
            }
        };
    }, []);

    return (
        <div
            className={`chat-action-bar ${embedded ? "chat-action-bar-embedded" : ""}`}
        >
            <input
                ref={fileInputRef}
                type="file"
                accept="image/*,audio/*"
                onChange={onFileUpload}
                style={{ display: "none" }}
            />
            <Button
                variant="ghost"
                size="sm"
                className="action-bar-icon"
                onClick={() => fileInputRef.current?.click()}
                disabled={loading}
                title="上传图片"
            >
                <Image size={20} />
            </Button>
            <Button
                variant="ghost"
                size="sm"
                className={`action-bar-icon ${isRecording ? "recording" : ""}`}
                onClick={toggleVoice}
                disabled={loading}
                title={isRecording ? "停止录音" : "语音输入"}
            >
                {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
            </Button>
            <Textarea
                value={input}
                onChange={(e) => onInputChange(e.target.value)}
                placeholder={t("ai.chatPlaceholder")}
                onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        onSend();
                    }
                }}
                disabled={loading}
                rows={1}
                className="action-bar-input"
            />
            <Button
                onClick={onSend}
                disabled={loading || !input.trim()}
                className="action-bar-send"
                title={t("ai.send")}
            >
                <Send size={18} />
            </Button>
        </div>
    );
};

export default ChatActionBar;
