import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { getLogs, type LogEntry, getToken } from "../../services/api";
import { format } from "date-fns";
import { zhCN, enUS } from "date-fns/locale";
import {
    Loader2,
    RefreshCw,
    AlertCircle,
    CheckCircle2,
    Info,
    Clock,
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "../ui/Card";
import { Button } from "../ui/Button";
import { Badge } from "../ui/Badge";
import EmailViewer from "../ui/EmailViewer";
import LoadingSpinner from "../ui/LoadingSpinner";
import "../../styles/LogViewer.css";

const LogViewer: React.FC = () => {
    const { t, i18n } = useTranslation();
    const dateLocale = i18n.language === "zh-CN" ? zhCN : enUS;
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [page, setPage] = useState(0);
    const [total, setTotal] = useState(0);
    const limit = 50;

    const fetchLogs = async (pageIndex: number, isReset: boolean) => {
        setLoading(true);
        try {
            const currentOffset = pageIndex * limit;
            console.log(
                `Fetching logs: page=${pageIndex}, offset=${currentOffset}`,
            );
            const response = await getLogs({ limit, offset: currentOffset });
            console.log("Logs fetched:", response);

            if (isReset) {
                setLogs(response.logs);
                setPage(0);
            } else {
                setLogs((prev) => [...prev, ...response.logs]);
            }
            setTotal(response.total);
        } catch (err: any) {
            console.error("Failed to fetch logs:", err);
            setError(err.message || t("logs.loadFailed"));
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchLogs(0, true);

        const token = getToken();
        if (!token) return;

        let unsub: (() => void) | null = null;
        (async () => {
            const wsClient = (await import("../../services/wsClient")).default;
            wsClient.connectIfNeeded(token);
            unsub = wsClient.subscribe("userLog", (data: any) => {
                try {
                    if (data.log) {
                        setLogs((prev) => [data.log, ...prev]);
                        setTotal((prev) => prev + 1);
                    }
                } catch (e) {
                    console.error(e);
                }
            });
        })();

        return () => {
            if (unsub) unsub();
        };
    }, []);

    const handleLoadMore = () => {
        const nextPage = page + 1;
        setPage(nextPage);
        fetchLogs(nextPage, false);
    };

    const handleRefresh = () => {
        fetchLogs(0, true);
    };

    const getIconForType = (type: string) => {
        if (type.includes("Error"))
            return <AlertCircle className="text-red-500" size={18} />;
        if (
            type.includes("Success") ||
            type.includes("Created") ||
            type.includes("Pushed")
        )
            return <CheckCircle2 className="text-green-500" size={18} />;
        if (type.includes("Conflict"))
            return <AlertCircle className="text-orange-500" size={18} />;
        return <Info className="text-blue-500" size={18} />;
    };

    const getBadgeVariant = (type: string) => {
        if (type.includes("Error")) return "error";
        if (
            type.includes("Success") ||
            type.includes("Created") ||
            type.includes("Pushed")
        )
            return "success";
        if (type.includes("Conflict")) return "warning";
        return "info";
    };

    const formatTime = (isoString: string) => {
        try {
            return format(new Date(isoString), "MM-dd HH:mm:ss", {
                locale: dateLocale,
            });
        } catch (e) {
            return isoString;
        }
    };

    const isEmailLog = (log: LogEntry) => {
        return (
            log.type === "external_schedule_request" ||
            log.type === "ai_email_processed" ||
            log.type === "ai_email_failed"
        );
    };

    return (
        <Card className="log-viewer-container">
            <CardHeader className="log-header">
                <CardTitle>{t("logs.systemLogs")}</CardTitle>
                <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRefresh}
                    disabled={loading}
                >
                    <RefreshCw
                        size={16}
                        className={loading ? "spin" : ""}
                        style={{ marginRight: "6px" }}
                    />{" "}
                    {t("common.refresh")}
                </Button>
            </CardHeader>

            <CardContent className="log-content-wrapper">
                {error && <div className="error-banner">{error}</div>}

                <div className="logs-list">
                    {logs.length === 0 && !loading ? (
                        <div className="empty-state">{t("logs.noLogs")}</div>
                    ) : (
                        logs.map((log) => (
                            <div key={log.id} className="log-item">
                                <div className="log-icon">
                                    {getIconForType(log.type)}
                                </div>
                                <div className="log-content">
                                    <div className="log-message">
                                        {log.message}
                                    </div>
                                    <div className="log-meta">
                                        <Badge
                                            variant={getBadgeVariant(log.type)}
                                        >
                                            {log.type}
                                        </Badge>
                                        <span className="log-time">
                                            <Clock size={12} />{" "}
                                            {formatTime(log.time)}
                                        </span>
                                    </div>
                                    {log.payload &&
                                        Object.keys(log.payload).length > 0 && (
                                            <details className="log-payload">
                                                <summary>
                                                    {t("logs.details")}
                                                </summary>
                                                {log.payload.llmResponse && (
                                                    <>
                                                        <strong>
                                                            {t(
                                                                "logs.aiFullResponse",
                                                            )}
                                                        </strong>
                                                        <pre>
                                                            {JSON.stringify(
                                                                log.payload
                                                                    .llmResponse,
                                                                null,
                                                                2,
                                                            )}
                                                        </pre>
                                                    </>
                                                )}
                                                {log.payload.error && (
                                                    <>
                                                        <strong
                                                            style={{
                                                                color: "red",
                                                            }}
                                                        >
                                                            {t("logs.error")}
                                                        </strong>
                                                        <pre
                                                            style={{
                                                                color: "red",
                                                            }}
                                                        >
                                                            {log.payload.error}
                                                        </pre>
                                                    </>
                                                )}
                                                <pre>
                                                    {JSON.stringify(
                                                        log.payload,
                                                        null,
                                                        2,
                                                    )}
                                                </pre>
                                            </details>
                                        )}
                                    {isEmailLog(log) &&
                                        log.payload?.emailId && (
                                            <div style={{ marginTop: 6 }}>
                                                <EmailViewer
                                                    emailId={
                                                        log.payload.emailId
                                                    }
                                                    emailMeta={{
                                                        subject:
                                                            log.payload
                                                                .emailSubject ||
                                                            t(
                                                                "email.noSubject",
                                                            ),
                                                        from:
                                                            log.payload.from ||
                                                            log.payload
                                                                .emailFrom,
                                                        receivedAt:
                                                            log.payload
                                                                .receivedAt ||
                                                            log.payload
                                                                .emailReceivedAt,
                                                    }}
                                                />
                                            </div>
                                        )}
                                </div>
                            </div>
                        ))
                    )}
                    {loading && <LoadingSpinner />}
                </div>

                {logs.length < total && !loading && (
                    <div
                        style={{
                            display: "flex",
                            justifyContent: "center",
                            marginTop: "16px",
                        }}
                    >
                        <Button variant="ghost" onClick={handleLoadMore}>
                            {t("logs.loadMore")}
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default LogViewer;
