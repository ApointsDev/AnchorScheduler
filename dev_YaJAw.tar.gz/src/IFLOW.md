# AI Time Manager - 智能时间管理助手

## 项目概述

AI Time Manager 是一个专为西交利物浦大学（XJTLU）学生设计的智能时间管理应用。它能绑定西浦eBridge系统，获取课程表并同步到邮箱日历和MS ToDo，同时通过绑定西浦邮箱账号，实现AI读邮件提取日程信息，实现全自动化的日程管理。

### 核心技术栈
- **前端**: React 19.2.0 + TypeScript 5.9.3
- **后端**: Node.js/Express 4.21.1 + TypeScript
- **构建工具**: Vite 7.2.2
- **AI服务**: OpenAI GPT-4o API
- **数据库**: SQLite (users.db)

### 项目架构
```
AI-Time-Manager/
├── src/                    # 前端源代码
│   ├── components/         # React 组件 (Login, Register, Dashboard)
│   ├── services/           # API 服务 (认证、状态管理)
│   ├── styles/             # 样式文件
│   └── App.tsx             # 主应用组件
├── server/                 # 后端源代码
│   ├── Services/           # 业务逻辑服务 (MStodo, LLM, Exchange)
│   ├── Utils/              # 工具类 (日志)
│   ├── routes/             # API 路由
│   └── index.ts            # 服务端入口
├── package.json            # 项目配置
└── README.md               # 项目说明
```

## 功能特性

### 用户认证
- 用户注册/登录/登出
- JWT令牌管理
- 本地存储用户信息

### 集成服务
- **Microsoft To Do**: 任务同步功能
- **XJTLU eBridge**: 课程表获取和同步
- **Exchange服务**: 邮件日程信息提取
- **AI服务**: 智能邮件内容解析

### 状态管理
- Microsoft To Do连接状态
- eBridge连接状态
- 用户认证状态

## 前端组件结构

### 主要组件
- `App.tsx`: 应用主组件，管理路由和状态
- `components/Login.tsx`: 用户登录界面
- `components/Register.tsx`: 用户注册界面
- `components/Dashboard.tsx`: 主仪表板，显示连接状态和功能

### 样式文件
- `styles/AuthForms.css`: 认证表单样式
- `styles/Dashboard.css`: 仪表板样式
- `App.css`: 全局样式

### API服务
- `services/api.ts`: 处理所有后端API通信，包括：
  - 用户认证（登录、注册）
  - Microsoft OAuth流程
  - eBridge密码更新
  - 服务状态查询

## 后端架构

### API端点
- `/api/register`: 用户注册
- `/api/login`: 用户登录
- `/api/auth`: Microsoft OAuth流程
- `/api/updateEbridgePassword`: 更新eBridge密码
- `/api/status/microsoft-todo`: 获取Microsoft To Do状态
- `/api/status/ebridge`: 获取eBridge状态

### 服务模块
- `Services/MStodo.ts`: Microsoft To Do服务
- `Services/LLMApi.ts`: AI服务（OpenAI集成）
- `Services/exchangeClient.ts`: Exchange服务（邮件处理）
- `Services/dbService.ts`: 数据库服务

## 开发约定

### 代码风格
- 使用TypeScript进行类型安全开发
- React函数组件配合Hooks
- 异步操作使用async/await
- 错误处理采用try-catch模式

### 本地存储
- `auth_token`: JWT认证令牌
- `user_email`: 用户邮箱
- `user_XJTLUaccount`: XJTLU账号

### 环境变量
- `PORT`: 服务器端口
- `JWT_SECRET`: JWT密钥
- `MS_CLIENT_ID/MS_CLIENT_SECRET`: Microsoft OAuth配置
- `OPENAI_API_KEY`: OpenAI API密钥

## 构建与运行

### 开发模式
```bash
# 安装依赖
npm install

# 同时启动前端和后端
npm run dev:all

# 单独启动前端
npm run dev

# 单独启动后端
npm run server
```

### 生产构建
```bash
# 构建项目
npm run build

# 预览构建结果
npm run preview
```

### 环境配置
复制并配置环境文件：
```bash
cp server/.env.template server/.env
```

## 项目特点

1. **多服务集成**: 同时集成Microsoft To Do和XJTLU eBridge服务
2. **AI智能处理**: 使用AI解析邮件内容提取日程信息
3. **响应式界面**: 基于React的现代化用户界面
4. **安全认证**: JWT令牌认证机制
5. **状态管理**: 实时显示各服务连接状态
6. **中文界面**: 针对中国学生优化的中文用户界面

## 使用场景

1. **学生用户**: 西浦学生可以同步课程表到Microsoft To Do
2. **日程管理**: 自动根据邮件和课程表创建任务
3. **跨平台同步**: 通过日历和待办事项应用在多设备管理日程

该项目专注于为XJTLU学生提供智能化的时间管理解决方案，通过自动化同步和AI分析减少手动操作，提升学习效率。