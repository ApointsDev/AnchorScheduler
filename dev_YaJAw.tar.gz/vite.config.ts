import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api/ebridge': {
        target: 'http://localhost:3000',
        changeOrigin: true
      },
      '/api': {
        target: 'https://api.schedule.apoints.cn',
        changeOrigin: true
      }
    }
  }
})
