// 用户 CRUD 操作
import type { Database } from "sqlite";
import type { User } from "../../index";
import { mapRowToTask } from "./taskMapper";

export class UserStore {
    constructor(private db: Database) {}

    async addUser(user: User): Promise<void> {
        await this.db.run(
            `INSERT INTO users
           (id, email, name, XJTLUaccount, XJTLUPassword, passwordHash, JWTtoken, MStoken, MSRefreshToken, MSbinded,
            CalDavBaseUrl, CalDavUsername, CalDavPassword, CalDavPrincipalUrl, CalDavCalendarHome, CalDavCalendarUrl, CalDavSyncToken, CalDavEnabled, CalDavLastSyncAt,
            ExchangeAccessToken, ExchangeRefreshToken, ExchangeTokenExpiresAt, ExchangeBinded,
            ImapBinded, ImapEmail, ImapPassword, ImapHost, ImapPort, ImapTls, CAFSub, CAFAccessToken, CAFRefreshToken, CAFTokenExpiresAt, ebridgeBinded, timetableUrl, timetableFetchLevel, mailReadingSpan, conflictBoundaryInclusive, weekOffset, autoSchedulePromotions, stripReplyPrefix, onboardingCompleted)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                user.id,
                user.email,
                user.name,
                user.XJTLUaccount,
                user.XJTLUPassword,
                user.passwordHash,
                user.JWTtoken,
                user.MStoken,
                user.MSRefreshToken,
                user.MSbinded ? 1 : 0,
                user.CalDavBaseUrl,
                user.CalDavUsername,
                user.CalDavPassword,
                user.CalDavPrincipalUrl,
                user.CalDavCalendarHome,
                user.CalDavCalendarUrl,
                user.CalDavSyncToken,
                user.CalDavEnabled ? 1 : 0,
                user.CalDavLastSyncAt,
                user.ExchangeAccessToken,
                user.ExchangeRefreshToken,
                user.ExchangeTokenExpiresAt,
                user.ExchangeBinded ? 1 : 0,
                user.ImapBinded ? 1 : 0,
                user.ImapEmail,
                user.ImapPassword,
                user.ImapHost,
                user.ImapPort,
                user.ImapTls ? 1 : 0,
                user.CAFSub,
                user.CAFAccessToken,
                user.CAFRefreshToken,
                user.CAFTokenExpiresAt,
                user.ebridgeBinded ? 1 : 0,
                user.timetableUrl,
                user.timetableFetchLevel || 0,
                user.mailReadingSpan ?? 30,
                user.conflictBoundaryInclusive ? 1 : 0,
                user.weekOffset || 0,
                user.autoSchedulePromotions ? 1 : 0,
                user.stripReplyPrefix !== false ? 1 : 0,
                user.onboardingCompleted ? 1 : 0,
            ],
        );
    }

    async updateUser(user: User): Promise<void> {
        await this.db.run(
            `UPDATE users
             SET email = ?, name = ?, XJTLUaccount = ?, XJTLUPassword = ?, passwordHash = ?,
                 JWTtoken = ?, MStoken = ?, MSRefreshToken = ?, MSbinded = ?,
                 ExchangeAccessToken = ?, ExchangeRefreshToken = ?, ExchangeTokenExpiresAt = ?, ExchangeBinded = ?,
                 ImapBinded = ?, ImapEmail = ?, ImapPassword = ?, ImapHost = ?, ImapPort = ?, ImapTls = ?,
                 CAFSub = ?, CAFAccessToken = ?, CAFRefreshToken = ?, CAFTokenExpiresAt = ?,
                 CalDavBaseUrl = ?, CalDavUsername = ?, CalDavPassword = ?, CalDavPrincipalUrl = ?,
                 CalDavCalendarHome = ?, CalDavCalendarUrl = ?, CalDavSyncToken = ?, CalDavEnabled = ?, CalDavServerEnabled = ?, CalDavLastSyncAt = ?,
                 ebridgeBinded = ?, timetableUrl = ?, timetableFetchLevel = ?, mailReadingSpan = ?, conflictBoundaryInclusive = ?, weekOffset = ?, autoSchedulePromotions = ?, stripReplyPrefix = ?, onboardingCompleted = ?, updatedAt = CURRENT_TIMESTAMP
             WHERE id = ?`,
            [
                user.email,
                user.name,
                user.XJTLUaccount,
                user.XJTLUPassword,
                user.passwordHash,
                user.JWTtoken,
                user.MStoken,
                user.MSRefreshToken,
                user.MSbinded ? 1 : 0,
                user.ExchangeAccessToken,
                user.ExchangeRefreshToken,
                user.ExchangeTokenExpiresAt,
                user.ExchangeBinded ? 1 : 0,
                user.ImapBinded ? 1 : 0,
                user.ImapEmail,
                user.ImapPassword,
                user.ImapHost,
                user.ImapPort,
                user.ImapTls ? 1 : 0,
                user.CAFSub,
                user.CAFAccessToken,
                user.CAFRefreshToken,
                user.CAFTokenExpiresAt,
                user.CalDavBaseUrl,
                user.CalDavUsername,
                user.CalDavPassword,
                user.CalDavPrincipalUrl,
                user.CalDavCalendarHome,
                user.CalDavCalendarUrl,
                user.CalDavSyncToken,
                user.CalDavEnabled ? 1 : 0,
                user.CalDavServerEnabled ? 1 : 0,
                user.CalDavLastSyncAt,
                user.ebridgeBinded ? 1 : 0,
                user.timetableUrl,
                user.timetableFetchLevel || 0,
                user.mailReadingSpan ?? 30,
                user.conflictBoundaryInclusive ? 1 : 0,
                user.weekOffset || 0,
                user.autoSchedulePromotions ? 1 : 0,
                user.stripReplyPrefix !== false ? 1 : 0,
                user.onboardingCompleted ? 1 : 0,
                user.id,
            ],
        );
    }

    async getUserById(id: string, getTasksByUserId: (uid: string) => Promise<any[]>): Promise<User | null> {
        const row: any = await this.db.get("SELECT * FROM users WHERE id = ?", [id]);
        if (!row) return null;
        const tasks = await getTasksByUserId(id);
        return this.mapRowToUser(row, tasks);
    }

    async getUserByEmail(email: string, getTasksByUserId: (uid: string) => Promise<any[]>): Promise<User | null> {
        const row: any = await this.db.get("SELECT * FROM users WHERE email = ?", [email]);
        if (!row) return null;
        const tasks = await getTasksByUserId(row.id);
        return this.mapRowToUser(row, tasks);
    }

    async getUserByCafSub(cafSub: string, getTasksByUserId: (uid: string) => Promise<any[]>): Promise<User | null> {
        const row: any = await this.db.get("SELECT * FROM users WHERE CAFSub = ?", [cafSub]);
        if (!row) return null;
        const tasks = await getTasksByUserId(row.id);
        return this.mapRowToUser(row, tasks);
    }

    async getAllUsers(getTasksByUserId: (uid: string) => Promise<any[]>): Promise<User[]> {
        const rows: any[] = await this.db.all("SELECT * FROM users");
        const users: User[] = [];
        for (const row of rows) {
            const tasks = await getTasksByUserId(row.id);
            users.push(this.mapRowToUser(row, tasks));
        }
        return users;
    }

    async updateUserHighEnergyPeriods(userId: string, periods: Record<number, any[]>): Promise<void> {
        await this.db.run("UPDATE users SET highEnergyPeriods = ? WHERE id = ?", [JSON.stringify(periods), userId]);
    }

    private mapRowToUser(row: any, tasks: any[]): User {
        return {
            id: row.id,
            email: row.email,
            name: row.name,
            XJTLUaccount: row.XJTLUaccount,
            XJTLUPassword: row.XJTLUPassword,
            passwordHash: row.passwordHash,
            JWTtoken: row.JWTtoken,
            MStoken: row.MStoken,
            MSRefreshToken: row.MSRefreshToken,
            MSbinded: row.MSbinded === 1,
            ExchangeAccessToken: row.ExchangeAccessToken,
            ExchangeRefreshToken: row.ExchangeRefreshToken,
            ExchangeTokenExpiresAt: row.ExchangeTokenExpiresAt,
            ExchangeBinded: row.ExchangeBinded === 1,
            ImapBinded: row.ImapBinded === 1,
            ImapEmail: row.ImapEmail,
            ImapPassword: row.ImapPassword,
            ImapHost: row.ImapHost,
            ImapPort: row.ImapPort,
            ImapTls: row.ImapTls === 1,
            CAFSub: row.CAFSub,
            CAFAccessToken: row.CAFAccessToken,
            CAFRefreshToken: row.CAFRefreshToken,
            CAFTokenExpiresAt: row.CAFTokenExpiresAt,
            CalDavBaseUrl: row.CalDavBaseUrl,
            CalDavUsername: row.CalDavUsername,
            CalDavPassword: row.CalDavPassword,
            CalDavPrincipalUrl: row.CalDavPrincipalUrl,
            CalDavCalendarHome: row.CalDavCalendarHome,
            CalDavCalendarUrl: row.CalDavCalendarUrl,
            CalDavSyncToken: row.CalDavSyncToken,
            CalDavEnabled: row.CalDavEnabled === 1,
            CalDavServerEnabled: row.CalDavServerEnabled === 1,
            CalDavLastSyncAt: row.CalDavLastSyncAt,
            ebridgeBinded: row.ebridgeBinded === 1,
            timetableUrl: row.timetableUrl || "",
            timetableFetchLevel: row.timetableFetchLevel || 0,
            mailReadingSpan: row.mailReadingSpan ?? 30,
            conflictBoundaryInclusive: row.conflictBoundaryInclusive === 1,
            weekOffset: row.weekOffset || 0,
            autoSchedulePromotions: row.autoSchedulePromotions === 1,
            stripReplyPrefix: row.stripReplyPrefix !== 0,
            onboardingCompleted: row.onboardingCompleted === 1,
            highEnergyPeriods: row.highEnergyPeriods ? JSON.parse(row.highEnergyPeriods) : {},
            tasks: tasks.map(mapRowToTask),
            emsClient: undefined,
        };
    }
}
