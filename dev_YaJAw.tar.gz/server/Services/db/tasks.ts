// 任务 CRUD 操作 — 使用统一的 mapRowToTask 消除重复
import type { Database } from "sqlite";
import type { Task } from "../../index";
import { toShanghaiISO } from "../../Utils/time.js";
import { assertNoConflict } from "../scheduleConflict";
import { mapRowToTask, normalizeImportance } from "./taskMapper";

export class TaskStore {
    constructor(
        private db: Database,
        private addUserLog: (userId: string, type: string, message: string, payload?: any) => Promise<any>,
    ) {}

    async addTask(userId: string, task: Task, boundaryConflict?: boolean, allowConflict: boolean = true): Promise<void> {
        const existing = await this.getTasksByUserId(userId);
        if (!allowConflict) {
            assertNoConflict(existing, task, { boundaryConflict: boundaryConflict ?? false });
        }
        task.importance = normalizeImportance(task.importance);
        try { if (task.startTime) task.startTime = toShanghaiISO(task.startTime); } catch (e) {}
        try { if (task.endTime) task.endTime = toShanghaiISO(task.endTime); } catch (e) {}
        try { if (task.dueDate) task.dueDate = toShanghaiISO(task.dueDate); } catch (e) {}

        await this.db.run(
            `INSERT INTO tasks (id, userId, name, description, dueDate, startTime, endTime, location, completed, pushedToMSTodo, body, attendees, recurrenceRule, parentTaskId, importance, scheduleType, quadrant)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [task.id, userId, task.name, task.description, task.dueDate, task.startTime, task.endTime, task.location, task.completed ? 1 : 0, task.pushedToMSTodo ? 1 : 0, task.body, task.attendees ? JSON.stringify(task.attendees) : null, task.recurrenceRule || null, task.parentTaskId || null, task.importance || "normal", task.scheduleType || "single", task.quadrant || null],
        );
        await this.addUserLog(userId, "task_created", `Created task ${task.name}`, { taskId: task.id, name: task.name });
    }

    async updateTask(task: Task, boundaryConflict?: boolean, allowConflict: boolean = false): Promise<void> {
        const row = await this.db.get("SELECT userId FROM tasks WHERE id = ?", [task.id]);
        if (row && row.userId) {
            const existing = await this.getTasksByUserId(row.userId);
            const others = existing.filter((t) => t.id !== task.id);
            if (!allowConflict) {
                assertNoConflict(others, task, { boundaryConflict: boundaryConflict ?? false });
            }
        }
        task.importance = normalizeImportance(task.importance);
        try { if (task.startTime) task.startTime = toShanghaiISO(task.startTime); } catch (e) {}
        try { if (task.endTime) task.endTime = toShanghaiISO(task.endTime); } catch (e) {}
        try { if (task.dueDate) task.dueDate = toShanghaiISO(task.dueDate); } catch (e) {}

        await this.db.run(
            `UPDATE tasks SET name = ?, description = ?, dueDate = ?, startTime = ?, endTime = ?, location = ?, completed = ?, pushedToMSTodo = ?, body = ?, attendees = ?, recurrenceRule = ?, parentTaskId = ?, importance = ?, scheduleType = ?, quadrant = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?`,
            [task.name, task.description, task.dueDate, task.startTime, task.endTime, task.location, task.completed ? 1 : 0, task.pushedToMSTodo ? 1 : 0, task.body, task.attendees ? JSON.stringify(task.attendees) : null, task.recurrenceRule || null, task.parentTaskId || null, task.importance || "normal", task.scheduleType || "single", task.quadrant || null, task.id],
        );
    }

    async patchTask(userId: string, taskId: string, updates: Partial<Task>, boundaryConflict?: boolean, allowConflict: boolean = false): Promise<Task> {
        const existingTask = await this.getTaskById(taskId);
        if (!existingTask) throw new Error("Task not found");
        if (updates.importance !== undefined) {
            updates.importance = normalizeImportance(updates.importance as string);
        }
        const updatedTask = { ...existingTask, ...updates, id: taskId };
        if (updates.startTime || updates.endTime) {
            const allTasks = await this.getTasksByUserId(userId);
            const otherTasks = allTasks.filter((t) => t.id !== taskId);
            if (!allowConflict) {
                assertNoConflict(otherTasks, updatedTask, { boundaryConflict: boundaryConflict ?? false });
            }
        }
        const fields = Object.keys(updates).filter((k) => k !== "id");
        if (fields.length === 0) return existingTask;
        if (updates.startTime) { try { updates.startTime = toShanghaiISO(updates.startTime as string); } catch (e) {} }
        if (updates.endTime) { try { updates.endTime = toShanghaiISO(updates.endTime as string); } catch (e) {} }
        if (updates.dueDate) { try { updates.dueDate = toShanghaiISO(updates.dueDate as string); } catch (e) {} }

        const setClauses = fields.map((f) => `${f} = ?`).join(", ");
        const values = fields.map((f) => {
            const key = f as keyof typeof updates;
            let value = updates[key];
            if (typeof value === "boolean") return value ? 1 : 0;
            if (typeof value === "object" && value !== null) return JSON.stringify(value);
            return value;
        });
        const sql = `UPDATE tasks SET ${setClauses}, updatedAt = CURRENT_TIMESTAMP WHERE id = ? AND userId = ?`;
        await this.db.run(sql, [...values, taskId, userId]);
        await this.addUserLog(userId, "task_updated", `Updated task ${taskId}`, { taskId, updates });
        return (await this.getTaskById(taskId)) as Task;
    }

    async getTasksByUserId(userId: string): Promise<Task[]> {
        const rows = await this.db.all("SELECT * FROM tasks WHERE userId = ?", [userId]);
        return rows.map(mapRowToTask);
    }

    async getTasksPage(
        userId: string,
        opts?: { start?: string; end?: string; q?: string; completed?: boolean; limit?: number; offset?: number; sortBy?: string; order?: "asc" | "desc" },
    ): Promise<{ tasks: Task[]; total: number }> {
        const where: string[] = ["userId = ?"];
        const params: any[] = [userId];
        if (opts?.start) { where.push("endTime >= ?"); params.push(opts.start); }
        if (opts?.end) { where.push("startTime <= ?"); params.push(opts.end); }
        if (typeof opts?.completed === "boolean") { where.push("completed = ?"); params.push(opts.completed ? 1 : 0); }
        if (opts?.q) {
            const like = `%${opts.q.toLowerCase()}%`;
            where.push("(LOWER(name) LIKE ? OR LOWER(description) LIKE ? OR LOWER(location) LIKE ?)");
            params.push(like, like, like);
        }
        const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
        const sortField = ["startTime", "dueDate", "name", "endTime"].includes(opts?.sortBy || "") ? opts!.sortBy : "startTime";
        const order = opts?.order === "desc" ? "DESC" : "ASC";
        const limit = Math.max(1, Math.min(500, opts?.limit || 50));
        const offset = Math.max(0, opts?.offset || 0);
        const countRow: any = await this.db.get(`SELECT COUNT(*) as cnt FROM tasks ${whereSql}`, params);
        const total = countRow ? countRow.cnt || 0 : 0;
        const sql = `SELECT * FROM tasks ${whereSql} ORDER BY ${sortField} ${order} LIMIT ? OFFSET ?`;
        const rows = await this.db.all(sql, params.concat([limit, offset]));
        return { tasks: rows.map(mapRowToTask), total };
    }

    async getOccurrencesPage(
        userId: string, rootTaskId: string,
        opts?: { limit?: number; offset?: number; sortBy?: string; order?: "asc" | "desc" },
    ): Promise<{ occurrences: Task[]; total: number }> {
        const where: string[] = ["userId = ?", "parentTaskId = ?"];
        const params: any[] = [userId, rootTaskId];
        const whereSql = `WHERE ${where.join(" AND ")}`;
        const sortField = ["startTime", "dueDate", "name", "endTime"].includes(opts?.sortBy || "") ? opts!.sortBy : "startTime";
        const order = opts?.order === "desc" ? "DESC" : "ASC";
        const limit = Math.max(1, Math.min(500, opts?.limit || 50));
        const offset = Math.max(0, opts?.offset || 0);
        const countRow: any = await this.db.get(`SELECT COUNT(*) as cnt FROM tasks ${whereSql}`, params);
        const total = countRow ? countRow.cnt || 0 : 0;
        const rows = await this.db.all(`SELECT * FROM tasks ${whereSql} ORDER BY ${sortField} ${order} LIMIT ? OFFSET ?`, params.concat([limit, offset]));
        return { occurrences: rows.map(mapRowToTask), total };
    }

    async getTaskById(id: string): Promise<Task | null> {
        const row = await this.db.get("SELECT * FROM tasks WHERE id = ?", [id]);
        if (!row) return null;
        return mapRowToTask(row);
    }

    async getTasksByIds(userId: string, ids: string[]): Promise<Task[]> {
        if (!ids || ids.length === 0) return [];
        const placeholders = ids.map(() => "?").join(",");
        const rows = await this.db.all(`SELECT * FROM tasks WHERE userId = ? AND id IN (${placeholders})`, [userId, ...ids]);
        return rows.map(mapRowToTask);
    }

    async deleteTask(id: string): Promise<boolean> {
        const row = await this.db.get("SELECT userId FROM tasks WHERE id = ?", [id]);
        const userId = row ? row.userId : null;
        const result: any = await this.db.run("DELETE FROM tasks WHERE id = ?", [id]);
        const success = (result?.changes || 0) > 0;
        if (success && userId) {
            await this.addUserLog(userId, "task_deleted", `Deleted task ${id}`, { taskId: id });
        }
        return success;
    }

    async deleteTasksByPattern(userId: string, pattern: string): Promise<number> {
        const rows = await this.db.all("SELECT id FROM tasks WHERE userId = ? AND id LIKE ?", [userId, pattern]);
        const ids = rows.map((r: any) => r.id);
        if (ids.length === 0) return 0;
        const result: any = await this.db.run("DELETE FROM tasks WHERE userId = ? AND id LIKE ?", [userId, pattern]);
        const count = result?.changes || 0;
        if (count > 0) {
            await this.addUserLog(userId, "tasks_deleted_pattern", `Deleted ${count} tasks matching pattern ${pattern}`, { pattern, count, deletedIds: ids });
        }
        return count;
    }
}
