// 数据库服务入口 — 组合所有子模块，保持向后兼容的 API
import sqlite3 from "sqlite3";
import { open } from "sqlite";
import type { Database } from "sqlite";
import { logger } from "../../Utils/logger.js";
import type { User, Task } from "../../index";

// ── 共享类型 ─────────────────────────────────────────────────

export interface LogEntry {
    id: string;
    time: string;
    type: string;
    message: string;
    payload?: unknown;
}

export interface TaskPageOpts {
    start?: string;
    end?: string;
    q?: string;
    completed?: boolean;
    limit?: number;
    offset?: number;
    sortBy?: string;
    order?: "asc" | "desc";
}

export interface OccurrencePageOpts {
    limit?: number;
    offset?: number;
    sortBy?: string;
    order?: "asc" | "desc";
}

export interface LogPageOpts {
    limit?: number;
    offset?: number;
    since?: string;
    until?: string;
    type?: string;
}

export interface CalendarEventMapEntry {
    userId: string;
    provider: string;
    localTaskId: string;
    remoteUid?: string;
    remoteHref?: string;
    remoteEtag?: string;
    calendarUrl?: string;
    rawData?: string;
}

export interface SharedScheduleData {
    id: string;
    userId: string;
    token: string;
    name: string;
    dateStart?: string;
    dateEnd?: string;
    taskIds?: string;
    expiresAt?: string;
}

export interface RefreshUserTasksOpts {
    addedIds?: string[];
    updatedIds?: string[];
    deletedIds?: string[];
}
import { runMigrations } from "./migrations";
import { UserStore } from "./users";
import { TaskStore } from "./tasks";
import { UserLogStore } from "./userLogs";
import { AdminStore } from "./admin";
import { EmailAiStore } from "./emailAi";
import { CalendarEventMapStore } from "./calendarEventMap";
import { ScheduleQueueStore } from "./scheduleQueue";
import { ChatContextStore } from "./chatContext";
import { SharedScheduleStore } from "./sharedSchedule";

export class DatabaseService {
    private db: Database | null = null;

    // 子模块实例（初始化后可用）
    users!: UserStore;
    tasks!: TaskStore;
    logs!: UserLogStore;
    admin!: AdminStore;
    emailAi!: EmailAiStore;
    calendarEventMap!: CalendarEventMapStore;
    scheduleQueue!: ScheduleQueueStore;
    chatContext!: ChatContextStore;
    sharedSchedule!: SharedScheduleStore;

    async initialize() {
        try {
            const dbPath = process.env.WEBSITE_INSTANCE_ID
                ? "/home/data/users.db"
                : "./private/users.db";

            logger.info(`Initializing database at path: ${dbPath}`);

            this.db = await open({
                filename: dbPath,
                driver: sqlite3.Database,
            });

            await runMigrations(this.db);

            // 初始化子模块（依赖注入）
            this.logs = new UserLogStore(this.db);
            this.tasks = new TaskStore(this.db, (userId, type, msg, payload) =>
                this.logs.add(userId, type, msg, payload),
            );
            this.users = new UserStore(this.db);
            this.admin = new AdminStore(this.db);
            this.emailAi = new EmailAiStore(this.db);
            this.calendarEventMap = new CalendarEventMapStore(this.db);
            this.scheduleQueue = new ScheduleQueueStore(this.db);
            this.chatContext = new ChatContextStore(this.db);
            this.sharedSchedule = new SharedScheduleStore(this.db);

            logger.success("Database initialized successfully");
        } catch (error) {
            logger.error("Failed to initialize database:", error);
            throw error;
        }
    }

    // ── 向后兼容的代理方法 ──

    // User Logs
    setLogListener(listener: (userId: string, log: LogEntry) => void) {
        this.logs.setLogListener(listener);
    }
    async addUserLog(
        userId: string,
        type: string,
        message: string,
        payload?: unknown,
    ) {
        return this.logs.add(userId, type, message, payload);
    }
    async getUserLogsPage(userId: string, opts?: LogPageOpts) {
        return this.logs.getPage(userId, opts);
    }

    // Users
    async addUser(user: User) {
        await this.users.addUser(user);
        for (const task of user.tasks || []) {
            await this.tasks.addTask(user.id, task);
        }
    }
    async updateUser(user: User) {
        return this.users.updateUser(user);
    }
    async getUserById(id: string) {
        return this.users.getUserById(id, (uid) =>
            this.tasks.getTasksByUserId(uid),
        );
    }
    async getUserByEmail(email: string) {
        return this.users.getUserByEmail(email, (uid) =>
            this.tasks.getTasksByUserId(uid),
        );
    }
    async getUserByCafSub(cafSub: string) {
        return this.users.getUserByCafSub(cafSub, (uid) =>
            this.tasks.getTasksByUserId(uid),
        );
    }
    async getAllUsers() {
        return this.users.getAllUsers((uid) =>
            this.tasks.getTasksByUserId(uid),
        );
    }
    async updateUserHighEnergyPeriods(
        userId: string,
        periods: Record<
            number,
            { startHour: number; endHour: number; score: number }[]
        >,
    ) {
        return this.users.updateUserHighEnergyPeriods(userId, periods);
    }

    // Tasks
    async addTask(
        userId: string,
        task: Task,
        boundaryConflict?: boolean,
        allowConflict?: boolean,
    ) {
        return this.tasks.addTask(
            userId,
            task,
            boundaryConflict,
            allowConflict,
        );
    }
    async updateTask(
        task: Task,
        boundaryConflict?: boolean,
        allowConflict?: boolean,
    ) {
        return this.tasks.updateTask(task, boundaryConflict, allowConflict);
    }
    async patchTask(
        userId: string,
        taskId: string,
        updates: Partial<Task>,
        boundaryConflict?: boolean,
        allowConflict?: boolean,
    ) {
        return this.tasks.patchTask(
            userId,
            taskId,
            updates,
            boundaryConflict,
            allowConflict,
        );
    }
    async getTasksByUserId(userId: string) {
        return this.tasks.getTasksByUserId(userId);
    }
    async getTasksPage(userId: string, opts?: TaskPageOpts) {
        return this.tasks.getTasksPage(userId, opts);
    }
    async getOccurrencesPage(
        userId: string,
        rootTaskId: string,
        opts?: OccurrencePageOpts,
    ) {
        return this.tasks.getOccurrencesPage(userId, rootTaskId, opts);
    }
    async getTaskById(id: string) {
        return this.tasks.getTaskById(id);
    }
    async getTasksByIds(userId: string, ids: string[]) {
        return this.tasks.getTasksByIds(userId, ids);
    }
    async deleteTask(id: string) {
        return this.tasks.deleteTask(id);
    }
    async deleteTasksByPattern(userId: string, pattern: string) {
        return this.tasks.deleteTasksByPattern(userId, pattern);
    }
    async refreshUserTasks(user: { id: string; tasks?: Task[] }) {
        const tasks = await this.tasks.getTasksByUserId(user.id);
        user.tasks = tasks;
    }
    async refreshUserTasksIncremental(
        user: { id: string; tasks?: Task[] },
        opts?: RefreshUserTasksOpts,
    ) {
        user.tasks = user.tasks || [];
        if (opts?.deletedIds && opts.deletedIds.length > 0) {
            const delSet = new Set(opts.deletedIds);
            user.tasks = user.tasks.filter((t: Task) => !delSet.has(t.id));
        }
        const fetchIds: string[] = [];
        if (opts?.addedIds) fetchIds.push(...opts.addedIds);
        if (opts?.updatedIds) fetchIds.push(...opts.updatedIds);
        const uniqueFetchIds = Array.from(new Set(fetchIds));
        if (uniqueFetchIds.length > 0) {
            const rows = await this.tasks.getTasksByIds(
                user.id,
                uniqueFetchIds,
            );
            for (const r of rows) {
                const idx = user.tasks.findIndex((t: Task) => t.id === r.id);
                if (idx >= 0) {
                    user.tasks[idx] = r;
                } else {
                    user.tasks.push(r);
                }
            }
        }
    }

    // Admin
    async adminUpdateUserFields(
        userId: string,
        updates: Record<string, unknown>,
    ) {
        return this.admin.updateUserFields(userId, updates);
    }
    async deleteUser(userId: string) {
        return this.admin.deleteUser(userId);
    }

    // Email AI
    async markEmailAiProcessed(
        userId: string,
        emailId: string,
        provider?: string,
    ) {
        return this.emailAi.markProcessed(userId, emailId, provider);
    }
    async isEmailAiProcessed(
        userId: string,
        emailId: string,
        provider?: string,
    ) {
        return this.emailAi.isProcessed(userId, emailId, provider);
    }
    async getAiProcessedEmailIds(userId: string) {
        return this.emailAi.getProcessedIds(userId);
    }
    async deleteAiProcessedEmail(userId: string, emailId: string) {
        return this.emailAi.deleteProcessed(userId, emailId);
    }

    // Calendar Event Map
    async getCalendarEventMapByLocalId(
        userId: string,
        provider: string,
        localTaskId: string,
    ) {
        return this.calendarEventMap.getByLocalId(
            userId,
            provider,
            localTaskId,
        );
    }
    async getCalendarEventMapByRemoteUid(
        userId: string,
        provider: string,
        remoteUid: string,
    ) {
        return this.calendarEventMap.getByRemoteUid(
            userId,
            provider,
            remoteUid,
        );
    }
    async upsertCalendarEventMap(entry: CalendarEventMapEntry) {
        return this.calendarEventMap.upsert(entry);
    }
    async deleteCalendarEventMapByLocalId(
        userId: string,
        provider: string,
        localTaskId: string,
    ) {
        return this.calendarEventMap.deleteByLocalId(
            userId,
            provider,
            localTaskId,
        );
    }

    // Schedule Queue
    async getScheduleQueueByUser(userId: string) {
        return this.scheduleQueue.getByUser(userId);
    }
    async getScheduleQueueById(id: string) {
        return this.scheduleQueue.getById(id);
    }
    async updateScheduleQueueStatus(id: string, status: string) {
        return this.scheduleQueue.updateStatus(id, status);
    }
    async deleteScheduleQueueItem(id: string) {
        return this.scheduleQueue.delete(id);
    }
    async addScheduleToQueue(userId: string, rawRequest: string) {
        return this.scheduleQueue.add(userId, rawRequest);
    }

    // Chat Context
    async getChatContexts(userId: string) {
        return this.chatContext.listContexts(userId);
    }
    async createChatContext(userId: string) {
        return this.chatContext.create(userId);
    }
    async getChatContext(contextId: string) {
        return this.chatContext.getMessages(contextId);
    }
    async deleteChatContext(contextId: string) {
        return this.chatContext.delete(contextId);
    }
    async getChatHistory(userId: string) {
        return this.chatContext.getActiveHistory(userId);
    }
    async saveChatHistory(
        userId: string,
        messagesJson: string,
        contextId?: string,
    ) {
        return this.chatContext.save(userId, messagesJson, contextId);
    }

    // Shared Schedule
    async createSharedSchedule(data: SharedScheduleData) {
        return this.sharedSchedule.create(data);
    }
    async getSharedScheduleByToken(token: string) {
        return this.sharedSchedule.getByToken(token);
    }
    async getSharedSchedulesByUser(userId: string) {
        return this.sharedSchedule.listByUser(userId);
    }
    async deleteSharedSchedule(token: string, userId: string) {
        return this.sharedSchedule.delete(token, userId);
    }

    async close() {
        if (this.db) {
            await this.db.close();
            this.db = null;
        }
    }
}

export const dbService = new DatabaseService();
