// 数据库迁移 — 所有 CREATE TABLE 和 ALTER TABLE 操作
import type { Database } from "sqlite";
import { logger } from "../../Utils/logger.js";

export async function runMigrations(db: Database): Promise<void> {
    // ── 用户表 ──
    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            XJTLUaccount TEXT,
            XJTLUPassword TEXT,
            passwordHash TEXT,
            JWTtoken TEXT,
            MStoken TEXT,
            MSbinded BOOLEAN DEFAULT 0,
            ebridgeBinded BOOLEAN DEFAULT 0,
            timetableUrl TEXT DEFAULT '',
            timetableFetchLevel INTEGER DEFAULT 0,
            mailReadingSpan INTEGER DEFAULT 30,
            conflictBoundaryInclusive BOOLEAN DEFAULT 0,
            MSRefreshToken TEXT,
            CalDavBaseUrl TEXT,
            CalDavUsername TEXT,
            CalDavPassword TEXT,
            CalDavPrincipalUrl TEXT,
            CalDavCalendarHome TEXT,
            CalDavCalendarUrl TEXT,
            CalDavSyncToken TEXT,
            CalDavEnabled BOOLEAN DEFAULT 0,
            CalDavLastSyncAt DATETIME,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    `);

    // ── 日程队列表 ──
    await db.exec(`
        CREATE TABLE IF NOT EXISTS schedule_queue (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            rawRequest TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    `);

    // ── AI 聊天记录表 ──
    await db.exec(`
        CREATE TABLE IF NOT EXISTS chat_history (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            messages TEXT NOT NULL,
            title TEXT NOT NULL DEFAULT '新对话',
            isActive INTEGER DEFAULT 1,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    `);

    // ── 任务表 ──
    await db.exec(`
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            dueDate TEXT,
            startTime TEXT,
            endTime TEXT,
            location TEXT,
            completed BOOLEAN DEFAULT 0,
            pushedToMSTodo BOOLEAN DEFAULT 0,
            body TEXT,
            attendees TEXT,
            recurrenceRule TEXT,
            parentTaskId TEXT,
            importance TEXT DEFAULT 'normal',
            scheduleType TEXT DEFAULT 'single',
            quadrant TEXT,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        );
    `);

    // ── 用户日志表 ──
    await db.exec(`
        CREATE TABLE IF NOT EXISTS user_logs (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            time DATETIME DEFAULT CURRENT_TIMESTAMP,
            type TEXT NOT NULL,
            message TEXT NOT NULL,
            payload TEXT,
            FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        );
    `);

    // ── CalDAV 事件映射表 ──
    await db.exec(`
        CREATE TABLE IF NOT EXISTS calendar_event_map (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            provider TEXT NOT NULL,
            localTaskId TEXT NOT NULL,
            remoteUid TEXT,
            remoteHref TEXT,
            remoteEtag TEXT,
            calendarUrl TEXT,
            rawData TEXT,
            lastSyncAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        );
    `);
    await db.exec(`CREATE INDEX IF NOT EXISTS idx_calendar_event_map_user ON calendar_event_map(userId);`);
    await db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_calendar_event_map_provider_remote ON calendar_event_map(provider, remoteUid, userId);`);
    await db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_calendar_event_map_provider_local ON calendar_event_map(provider, localTaskId);`);

    // ── 日程分享链接表 ──
    await db.exec(`
        CREATE TABLE IF NOT EXISTS shared_schedules (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            token TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL DEFAULT '',
            dateStart TEXT,
            dateEnd TEXT,
            taskIds TEXT,
            expiresAt TEXT,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        );
    `);
    await db.exec(`CREATE INDEX IF NOT EXISTS idx_shared_schedules_token ON shared_schedules(token);`);
    await db.exec(`CREATE INDEX IF NOT EXISTS idx_shared_schedules_user ON shared_schedules(userId);`);

    // ── AI 已处理邮件追踪表 ──
    await db.exec(`
        CREATE TABLE IF NOT EXISTS ai_processed_emails (
            userId TEXT NOT NULL,
            emailId TEXT NOT NULL,
            provider TEXT NOT NULL DEFAULT 'imap',
            processedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (userId, emailId, provider),
            FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        );
    `);
    await db.exec(`CREATE INDEX IF NOT EXISTS idx_ai_processed_user ON ai_processed_emails(userId);`);

    // ── ALTER TABLE 增量迁移 ──
    const alterStatements: string[] = [
        `ALTER TABLE chat_history ADD COLUMN title TEXT NOT NULL DEFAULT '历史对话'`,
        `ALTER TABLE chat_history ADD COLUMN isActive INTEGER DEFAULT 0`,
        `ALTER TABLE chat_history ADD COLUMN createdAt DATETIME`,
        `UPDATE chat_history SET createdAt = updatedAt WHERE createdAt IS NULL`,
        `ALTER TABLE users ADD COLUMN ExchangeBinded BOOLEAN DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN ExchangeAccessToken TEXT`,
        `ALTER TABLE users ADD COLUMN ExchangeRefreshToken TEXT`,
        `ALTER TABLE users ADD COLUMN ExchangeTokenExpiresAt INTEGER`,
        `ALTER TABLE users ADD COLUMN CAFSub TEXT`,
        `ALTER TABLE users ADD COLUMN CAFAccessToken TEXT`,
        `ALTER TABLE users ADD COLUMN CAFTokenExpiresAt INTEGER`,
        `ALTER TABLE users ADD COLUMN CAFRefreshToken TEXT`,
        `ALTER TABLE users ADD COLUMN ImapHost TEXT`,
        `ALTER TABLE users ADD COLUMN ImapPort INTEGER`,
        `ALTER TABLE users ADD COLUMN ImapBinded BOOLEAN DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN ImapEmail TEXT`,
        `ALTER TABLE users ADD COLUMN ImapPassword TEXT`,
        `ALTER TABLE users ADD COLUMN ImapTls BOOLEAN DEFAULT 1`,
        `ALTER TABLE users ADD COLUMN XJTLUaccount TEXT`,
        `ALTER TABLE users ADD COLUMN timetableUrl TEXT DEFAULT ''`,
        `ALTER TABLE users ADD COLUMN timetableFetchLevel INTEGER DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN mailReadingSpan INTEGER DEFAULT 30`,
        `ALTER TABLE users ADD COLUMN conflictBoundaryInclusive BOOLEAN DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN highEnergyPeriods TEXT DEFAULT '[]'`,
        `ALTER TABLE users ADD COLUMN weekOffset INTEGER DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN MSRefreshToken TEXT`,
        `ALTER TABLE users ADD COLUMN CalDavBaseUrl TEXT`,
        `ALTER TABLE users ADD COLUMN CalDavUsername TEXT`,
        `ALTER TABLE users ADD COLUMN CalDavPassword TEXT`,
        `ALTER TABLE users ADD COLUMN CalDavPrincipalUrl TEXT`,
        `ALTER TABLE users ADD COLUMN CalDavCalendarHome TEXT`,
        `ALTER TABLE users ADD COLUMN CalDavCalendarUrl TEXT`,
        `ALTER TABLE users ADD COLUMN CalDavSyncToken TEXT`,
        `ALTER TABLE users ADD COLUMN CalDavEnabled BOOLEAN DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN CalDavLastSyncAt DATETIME`,
        `ALTER TABLE users ADD COLUMN CalDavServerEnabled BOOLEAN DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN CalDavClientProfile TEXT DEFAULT 'auto'`,
        `ALTER TABLE users ADD COLUMN autoSchedulePromotions BOOLEAN DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN stripReplyPrefix BOOLEAN DEFAULT 1`,
        `ALTER TABLE users ADD COLUMN SmtpBinded BOOLEAN DEFAULT 0`,
        `ALTER TABLE users ADD COLUMN SmtpEmail TEXT`,
        `ALTER TABLE users ADD COLUMN SmtpPassword TEXT`,
        `ALTER TABLE users ADD COLUMN SmtpHost TEXT`,
        `ALTER TABLE users ADD COLUMN SmtpPort INTEGER`,
        `ALTER TABLE users ADD COLUMN SmtpTls BOOLEAN DEFAULT 1`,
        `ALTER TABLE tasks ADD COLUMN recurrenceRule TEXT`,
        `ALTER TABLE tasks ADD COLUMN parentTaskId TEXT`,
        `ALTER TABLE tasks ADD COLUMN importance TEXT DEFAULT 'normal'`,
        `ALTER TABLE tasks ADD COLUMN scheduleType TEXT DEFAULT 'single'`,
        `ALTER TABLE tasks ADD COLUMN quadrant TEXT`,
        `ALTER TABLE users ADD COLUMN onboardingCompleted BOOLEAN DEFAULT 0`,
    ];

    for (const stmt of alterStatements) {
        try {
            await db.exec(stmt);
        } catch (e) {
            const msg = (e as Error).message;
            // 只对 ALTER/DML 做日志忽略（列已存在等），CREATE INDEX 等已在上方处理
            if (!msg.includes("duplicate column name") && !msg.includes("already exists")) {
                logger.info(`Migration note: ${msg}`);
            }
        }
    }

    // scheduleType 回填
    try {
        await db.run(`UPDATE tasks SET scheduleType = 'recurring_daily' WHERE recurrenceRule LIKE '%"freq":"daily"%' AND (scheduleType IS NULL OR scheduleType = '' OR scheduleType = 'single')`);
        await db.run(`UPDATE tasks SET scheduleType = 'recurring_weekly' WHERE recurrenceRule LIKE '%"freq":"weekly"%' AND (scheduleType IS NULL OR scheduleType = '' OR scheduleType = 'single')`);
        await db.run(`UPDATE tasks SET scheduleType = 'recurring_weekly_by_week_number' WHERE recurrenceRule LIKE '%"freq":"weeklyByWeekNumber"%' AND (scheduleType IS NULL OR scheduleType = '' OR scheduleType = 'single')`);
        await db.run(`UPDATE tasks SET scheduleType = 'recurring_daily_on_days' WHERE recurrenceRule LIKE '%"freq":"dailyOnDays"%' AND (scheduleType IS NULL OR scheduleType = '' OR scheduleType = 'single')`);
    } catch (e) {
        logger.info("scheduleType backfill skipped or failed:", (e as Error).message);
    }
}
