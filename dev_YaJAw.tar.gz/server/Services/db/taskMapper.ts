// 任务行映射工具 — 消除 6 处重复的 row → Task 映射代码
import type { Task } from "../../index";

export function normalizeImportance(value?: string): "high" | "normal" | "low" {
    const normalized = typeof value === "string" ? value.toLowerCase() : "";
    if (
        normalized === "high" ||
        normalized === "low" ||
        normalized === "normal"
    ) {
        return normalized as "high" | "normal" | "low";
    }
    if (normalized === "medium") return "normal";
    return "normal";
}

/** 安全 JSON 解析 — 字符串为空或非法 JSON 时返回 undefined */
export function safeJsonParse(value: unknown): unknown {
    if (typeof value !== "string" || value.trim() === "") return undefined;
    try {
        return JSON.parse(value);
    } catch {
        return undefined;
    }
}

export function mapRowToTask(row: any): Task {
    return {
        id: row.id,
        name: row.name,
        description: row.description,
        dueDate: row.dueDate,
        startTime: row.startTime,
        endTime: row.endTime,
        location: row.location,
        completed: row.completed === 1,
        pushedToMSTodo: row.pushedToMSTodo === 1,
        body: row.body,
        attendees: safeJsonParse(row.attendees) as string[] | undefined,
        recurrenceRule: row.recurrenceRule || undefined,
        parentTaskId: row.parentTaskId || undefined,
        importance: normalizeImportance(row.importance),
        scheduleType: row.scheduleType || "single",
        quadrant: row.quadrant || undefined,
    };
}
