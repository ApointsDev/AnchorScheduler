// 通用邮箱邮件处理模块
// 提供 LLM 解析邮件 → 日程入队的统一管道，供 IMAP/Exchange/任意邮箱客户端复用

import { v4 as uuidv4 } from "uuid";
import { LLMApi } from "./LLMApi";
import { dbService } from "./dbService";
import { logUserEvent } from "./userLog";
import { logger } from "../Utils/logger.js";
import { toShanghaiISO } from "../Utils/time.js";
import type { User } from "../types/models";

/** 邮件数据的通用最小接口，IMAP/Exchange/其他客户端统一传入 */
export interface EmailForProcessing {
    id: string;
    subject: string;
    from?: { name: string; address: string };
    receivedAt: string;
    isRead: boolean;
    body?: string;
    hasAttachments?: boolean;
    attachmentsCount?: number;
}

export interface EmailProcessingResult {
    /** 成功入队的日程名称列表 */
    queuedSchedules: string[];
    /** 新创建的队列项 ID 列表（用于前端即时审批） */
    queueIds: string[];
    /** 是否触发了 LLM 工具调用 */
    toolCallsTriggered: boolean;
}

/**
 * 通用邮件处理管道：
 * 1. 调用 LLM 解析邮件
 * 2. 提取 add_schedule 工具调用
 * 3. 将日程请求入队（待用户确认）
 */
export async function processEmailWithLLM(
    user: User,
    email: EmailForProcessing,
    source: "imap" | "exchange" | string,
): Promise<EmailProcessingResult> {
    const result: EmailProcessingResult = {
        queuedSchedules: [],
        queueIds: [],
        toolCallsTriggered: false,
    };

    // 防止重复 AI 处理（兜底保护）
    if (email.id) {
        const alreadyProcessed = await dbService.isEmailAiProcessed(
            user.id,
            String(email.id),
            source,
        );
        if (alreadyProcessed) {
            logger.info(
                `邮件 ${email.id} (${email.subject}) 已 AI 处理过（${source}），跳过`,
            );
            return result;
        }
    }

    const llmApi = new LLMApi(
        process.env.OPENAI_API_KEY || "",
        process.env.OPENAI_MODEL || "deepseek-chat",
        user.autoSchedulePromotions ?? false,
    );

    try {
        const llmResponse = await llmApi.processEmail(email as any);

        // 始终记录 AI 处理日志
        const hasToolCalls = !!llmResponse?.tool_calls?.length;
        const summary = hasToolCalls
            ? `AI 处理邮件 "${email.subject}"，触发 ${llmResponse.tool_calls.length} 个工具调用`
            : `AI 处理邮件 "${email.subject}"，未触发工具调用`;

        await logUserEvent(user.id, "ai_email_processed", summary, {
            emailId: email.id,
            emailSubject: email.subject,
            emailFrom: email.from,
            emailReceivedAt: email.receivedAt,
            source,
            toolCallCount: llmResponse?.tool_calls?.length || 0,
            llmResponse: llmResponse, // 完整 AI 响应存档
        });

        if (!hasToolCalls) {
            logger.info(`LLM 未触发工具调用: ${email.subject}`);
            return result;
        }

        result.toolCallsTriggered = true;

        for (const toolCall of llmResponse.tool_calls) {
            const funcName = (toolCall as any)?.function?.name;
            const funcArgs = (toolCall as any)?.function?.arguments;
            if (funcName !== "add_schedule" || !funcArgs) continue;

            let toolArgs: any;
            try {
                toolArgs =
                    typeof funcArgs === "string"
                        ? JSON.parse(funcArgs)
                        : funcArgs;
            } catch {
                toolArgs = {};
            }
            if (!toolArgs.name) toolArgs.name = email.subject || "未命名任务";

            const payload = {
                args: {
                    ...toolArgs,
                    description: `来自邮件: ${email.subject}`,
                },
                email: {
                    id: email.id,
                    subject: email.subject,
                    from: email.from,
                    receivedAt: email.receivedAt,
                    isRead: email.isRead,
                    body: email.body || "",
                    hasAttachments: !!email.hasAttachments,
                    attachmentsCount: email.attachmentsCount ?? 0,
                },
                _meta: {
                    source,
                    createdAt: toShanghaiISO(),
                },
            };

            const queueId = await dbService.addScheduleToQueue(
                user.id,
                JSON.stringify(payload),
            );
            result.queuedSchedules.push(toolArgs.name);
            result.queueIds.push(queueId);

            await logUserEvent(
                user.id,
                "external_schedule_request",
                `外部请求创建日程: ${toolArgs.name}`,
                {
                    queueId,
                    emailId: email.id,
                    emailSubject: email.subject,
                    name: toolArgs.name,
                    startTime: toolArgs.startTime,
                    endTime: toolArgs.endTime,
                    // 存档 LLM 返回的完整工具调用链和参数
                    llmResponse: toolCall,
                },
            );
        }

        logger.success(
            `邮件处理完成: ${email.subject}, 入队 ${result.queuedSchedules.length} 个日程`,
        );

        // 标记 AI 已处理（持久化，防止重启/重连后重复处理）
        if (email.id) {
            try {
                await dbService.markEmailAiProcessed(
                    user.id,
                    String(email.id),
                    source,
                );
            } catch (err: any) {
                logger.error(
                    `标记 AI 已处理失败: ${err.message || "未知错误"}`,
                );
            }
        }
    } catch (err: unknown) {
        const message = err instanceof Error ? err.message : String(err);
        logger.error(`邮件 LLM 处理失败: ${message}`);

        // 失败也记录
        await logUserEvent(
            user.id,
            "ai_email_failed",
            `AI 处理邮件失败: ${email.subject}`,
            {
                emailId: email.id,
                emailSubject: email.subject,
                emailFrom: email.from,
                source,
                error: message,
            },
        );

        throw err;
    }

    return result;
}
