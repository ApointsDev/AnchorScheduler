// 全局数据模型类型定义
// Task, Profile, User 等被整个项目广泛引用的核心类型

import type { ExchangeClient } from "../Services/exchangeClient";
import type { ImapClient } from "../Services/imapClient";
import type { ScheduleType } from "../Services/types";

export interface Task {
    id: string;
    name: string;
    description: string;
    dueDate: string;
    startTime: string;
    endTime: string;
    location?: string;
    completed: boolean;
    pushedToMSTodo: boolean;
    body?: string;
    attendees?: string[];
    recurrenceRule?: string;
    parentTaskId?: string;
    importance?: "high" | "normal" | "low";
    isReminderOn?: boolean;
    scheduleType?: ScheduleType;
    estimatedDuration?: number;
    isFixed?: boolean;
    quadrant?: "q1" | "q2" | "q3" | "q4";
}

export interface Profile {
    company: string;
    school: string;
    campus: string;
    schoolYear: string;
}

export interface User {
    timetableUrl: string;
    timetableFetchLevel: number;
    mailReadingSpan: number;
    id: string;
    email: string;
    name: string;
    XJTLUaccount?: string;
    XJTLUPassword?: string;
    passwordHash?: string;
    JWTtoken?: string;
    MStoken?: string;
    MSRefreshToken?: string;
    MSbinded: boolean;
    ebridgeBinded: boolean;
    weekOffset?: number;
    tasks: Task[];
    emsClient?: ExchangeClient;
    conflictBoundaryInclusive?: boolean;
    isConflictScheduleAllowed?: boolean;
    userProfile?: Profile;
    highEnergyPeriods?: Record<
        number,
        { startHour: number; endHour: number; score: number }[]
    >;
    ExchangeAccessToken?: string;
    ExchangeRefreshToken?: string;
    ExchangeTokenExpiresAt?: number;
    ExchangeBinded?: boolean;
    ImapBinded?: boolean;
    ImapEmail?: string;
    ImapPassword?: string;
    ImapHost?: string;
    ImapPort?: number;
    ImapTls?: boolean;
    imapClient?: ImapClient;
    CAFSub?: string;
    CAFAccessToken?: string;
    CAFRefreshToken?: string;
    CAFTokenExpiresAt?: number;
    CalDavBaseUrl?: string;
    CalDavUsername?: string;
    CalDavPassword?: string;
    CalDavPrincipalUrl?: string;
    CalDavCalendarHome?: string;
    CalDavCalendarUrl?: string;
    CalDavSyncToken?: string;
    CalDavEnabled?: boolean;
    CalDavServerEnabled?: boolean;
    CalDavLastSyncAt?: string;
    /** CalDAV 客户端兼容模式 */
    CalDavClientProfile?:
        | "auto"
        | "apple"
        | "thunderbird"
        | "davx5"
        | "outlook"
        | "generic";
    /** 是否自动为推广/营销类邮件创建日程，默认 false */
    autoSchedulePromotions?: boolean;
    /** 是否去除邮件主题中的转发/回复前缀（如 "转发:", "Fwd:"），默认 true */
    stripReplyPrefix?: boolean;
    /** 引导页是否已完成（持久化到数据库，替代 localStorage） */
    onboardingCompleted?: boolean;
}
