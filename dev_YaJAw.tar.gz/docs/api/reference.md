> 父文档：[API 文档](README.md)

---

## 十九、数据结构

### Task（任务）
```typescript
interface Task {
    id: string;
    userId: string;
    name: string;
    description?: string;
    location?: string;
    startTime: string;        // ISO 8601
    endTime: string;          // ISO 8601
    completed: boolean;
    importance: "high" | "normal" | "low";
    quadrant?: "q1" | "q2" | "q3" | "q4";
    scheduleType?: "fixed" | "flexible"; // 已废弃
    recurrenceRule?: RecurrenceRule;
    parentTaskId?: string;
    source?: "manual" | "timetable" | "email" | "caldav";
    createdAt: string;
    updatedAt: string;
}
```

### RecurrenceRule（重复规则）
```typescript
interface RecurrenceRule {
    frequency: "daily" | "weekly" | "monthly" | "yearly";
    interval?: number;           // 间隔，默认 1
    count?: number;              // 总次数
    until?: string;              // 结束日期 ISO
    byDay?: string[];            // ["MO","WE","FR"]
    byMonthDay?: number[];
    byMonth?: number[];
}
```

### Email（邮件）
```typescript
interface Email {
    id: string;
    subject: string;
    from: string;
    to: string[];
    date: string;
    body: string;
    html?: string;
    attachments: Attachment[];
    isRead: boolean;
    isFlagged: boolean;
    aiProcessed: boolean;
}
```

### User（用户）
```typescript
interface User {
    id: string;
    email: string;
    name: string;
    xjtluAccount?: string;
    msToken?: string;
    exchangeToken?: string;
    imapConfig?: ImapConfig;
    caldavConfig?: CalDavConfig;
    calDavServerEnabled: boolean;
    settings: UserSettings;
    createdAt: string;
}
```

### ChatContext（聊天上下文）
```typescript
interface ChatContext {
    id: string;
    userId: string;
    title: string;
    createdAt: string;
    updatedAt: string;
}
```

---

## 二十、WebSocket

> 连接: `wss://schedule.apoints.cn/ws`  
> 需认证: 连接时传入 `?token=<JWT>`

### 服务端事件

| 事件 | 数据 | 说明 |
|------|------|------|
| `task_created` | `{ task: Task }` | 新任务创建 |
| `task_updated` | `{ task: Task }` | 任务更新 |
| `task_deleted` | `{ taskId: string }` | 任务删除 |
| `email_processed` | `{ emailId, result }` | AI 邮件处理完成 |
| `schedule_queue_update` | `{ count, items }` | 日程队列更新 |

### 客户端事件

| 事件 | 数据 | 说明 |
|------|------|------|
| `subscribe` | `{ channel: string }` | 订阅频道 |
| `unsubscribe` | `{ channel: string }` | 取消订阅 |

---

## 状态码约定

| 状态码 | 说明 |
|--------|------|
| 200 | 成功 |
| 201 | 创建成功 |
| 400 | 请求参数错误 |
| 401 | 未认证或 token 过期 |
| 403 | 无权限（如非管理员访问管理接口） |
| 404 | 资源不存在 |
| 409 | 冲突（如日程时间冲突） |
| 500 | 服务器内部错误 |
