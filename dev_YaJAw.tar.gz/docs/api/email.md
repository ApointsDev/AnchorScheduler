> 父文档：[API 文档](README.md)

---

## 七、邮件

> 全部需认证 🔒

### `GET /api/emails`
```
Query: page?, limit?, folder?
Response: { emails: Email[], total, page }
```
分页获取邮件列表。

### `GET /api/emails/search`
```
Query: query, limit?
Response: { emails: Email[] }
```
按关键词搜索邮件。

### `GET /api/emails/:emailId`
```
Response: { email: Email }
```
获取单封邮件详情（正文、HTML、附件）。

### `PUT /api/emails/:emailId/read`
标记邮件为已读。

### `POST /api/emails/:emailId/ai-process`
手动触发 AI 处理指定邮件（提取日程信息到队列）。
