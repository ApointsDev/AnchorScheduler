> 父文档：[API 文档](README.md)

---

## 四、用户与设置

> 全部需认证 🔒

### `GET /api/me`
```
Response: { email, name, xjtluAccount, settings: { ... } }
```
获取当前用户完整信息与设置。

### `GET /api/logs`
```
Query: start, end, type?, page?, limit?
Response: { logs: [...], total, page, limit }
```
获取操作日志（支持时间范围、类型过滤、分页）。

### `GET /api/settings/week`
```
Response: { currentWeek, academicBaseWeek, globalOffset, userOffset }
```
获取当前周数信息。

### `POST /api/settings/week`
```
Body: { currentWeek }  // 可选：校准当前周
Response: { success, currentWeek, userOffset }
```
更新用户级周数偏移。

### `POST /api/settings/conflict-mode`
```
Body: { mode: "inclusive" | "exclusive" }
```
设置冲突边界模式。

### `POST /api/settings/auto-schedule-promotions`
```
Body: { enabled: boolean }
```
开关：自动为推广邮件创建日程。

### `POST /api/settings/strip-reply-prefix`
```
Body: { enabled: boolean }
```
开关：AI 处理邮件时剥离回复/转发前缀。

### `GET /api/settings/onboarding`
```
Response: { completed: boolean, steps: [...] }
```
获取引导页完成状态。

### `POST /api/settings/onboarding`
```
Body: { step, completed }
```
更新引导页进度。
