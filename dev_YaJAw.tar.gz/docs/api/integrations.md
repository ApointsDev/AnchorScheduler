> 父文档：[API 文档](README.md)

---

## 十四、算法

> 全部需认证，挂载于 `/api/algorithms/*` 🔒

### `POST /api/algorithms/optimize-schedule`
```
Body: { tasks, fixedEvents, availableSlots, dependencies? }
Response: { success, assignments: { taskId: slotId } }
```
个人日程优化：根据任务、固定事件、可用时段给出最优安排。

### `POST /api/algorithms/schedule-meeting`
```
Body: { teamMembers, requirements: { duration, windowStart, windowEnd }, weights }
Response: { success, result: { optimalTime, participants, adjustments, totalCost } }
```
团队会议安排：找到最佳会议时间。

### `POST /api/algorithms/critical-path`
```
Body: { tasks: [{ id, duration, dependencies }], startDate }
Response: { success, result: { criticalPath, projectDuration, slackTimes, ... } }
```
项目关键路径分析。

### `POST /api/algorithms/community-detection`
```
Body: { tasks: [{ id, type, duration, tags }] }
Response: { success, communities }
```
任务社区发现：聚类相关任务。

### `POST /api/algorithms/analyze-energy`
基于历史任务数据识别用户高能时段。

### `POST /api/algorithms/schedule-tasks`
```
Body: { tasks, config: { workHours, preferences } }
Response: { success, scheduledTasks, metrics }
```
完整个人任务调度。

### `POST /api/algorithms/schedule-team-tasks`
```
Body: { members, meetingDetails, config }
Response: { success, result: { schedule, adjustments } }
```
完整团队任务调度。

---

## 十五、豆包多模态

> 全部需认证，挂载于 `/api/doubao/*` 🔒

### `POST /api/doubao/chat`
```
Body: FormData { image?, audio?, prompt }
Response: SSE 流
```
多模态对话（图片/音频 + 文字）。

### `POST /api/doubao/chat/text`
```
Body: { messages, stream? }
Response: SSE 流 或 JSON
```
纯文本豆包对话。

### `GET /api/doubao/status`
```
Response: { available, model }
```
检查豆包 API 状态。

---

## 十七、MCP

> 挂载于 `/api/mcp/*`

### `GET /api/mcp/sse` 🔒
```
Query: sessionId?
Response: SSE 流
```
启动 MCP SSE 会话。

### `POST /api/mcp/messages`
```
Query: sessionId
Body: JSON-RPC message
```
接收 MCP 客户端消息。

---

## 十八、Ebridge 代理

> 挂载于 `/api/ebridge/*`

### `ALL /api/ebridge/proxy/:domain/:rest*`
反向代理到 XJTLU ebridge/uim 服务。

### `POST /api/ebridge/save-url` 🔒
```
Body: { url }
```
保存课表 URL。

---

## 十三、分享

### `POST /api/share/create` 🔒
```
Body: { taskIds: string[], expiresIn?, dateRange? }
Response: { token, url }
```
创建日程分享链接。

### `GET /api/share/list` 🔒
```
Response: { shares: [...] }
```
获取当前用户的所有分享链接。

### `DELETE /api/share/:token` 🔒
删除指定分享链接。

### `GET /api/share/view/:token`
无需认证。通过 token 查看分享的日程。
