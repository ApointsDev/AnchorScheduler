> 父文档：[API 文档](README.md)

---

## 五、任务管理

> 全部需认证 🔒

### `GET /api/tasks`
```
Query: start, end, q?, completed?, sortBy?, order?, page?, limit?
Response: { tasks: Task[], total, page, limit }
```
分页获取任务，支持时间过滤、搜索、状态筛选、排序。

### `POST /api/tasks`
```
Body: { name, startTime, endTime, description?, location?,
        importance?, recurrenceRule?, conflictMode? }
Response: { task: Task }
```
创建任务（含冲突检测、重复规则解析）。

### `POST /api/tasks/batch`
```
Body: { tasks: [{ name, startTime, endTime, ... }] }
Response: { results: [{ status: "created"|"conflict"|"error", task?, error? }] }
```
批量创建任务。

### `POST /api/tasks/conflicts`
```
Body: { startTime, endTime, excludeTaskId? }
Response: { hasConflict: boolean, conflicts: Task[] }
```
冲突预检。

### `POST /api/tasks/classify-quadrants`
```
Body: { taskIds: string[] }
Response: { classified: { taskId, quadrant }[] }
```
LLM 自动归类任务到四象限。

### `PUT /api/tasks/:id`
```
Body: { name?, startTime?, endTime?, description?, completed?, ... }
Response: { task: Task }
```
全量更新任务。

### `PATCH /api/tasks/:id`
```
Body: { completed?: boolean, ... }
Response: { task: Task }
```
部分更新任务字段。

### `DELETE /api/tasks/:id`
```
Query: cascade=true    // 可选：级联删除子实例
Response: { success }
```
删除任务。

### `GET /api/tasks/parents`
```
Response: { tasks: Task[] }
```
列出所有含重复规则的父级日程及其子实例。

### `GET /api/tasks/:id/occurrences`
```
Query: page?, limit?, sortBy?, order?
Response: { occurrences: Task[], total }
```
获取重复任务的所有实例。

---

## 六、日程队列

> 全部需认证 🔒

### `GET /api/schedule-queue`
```
Response: { items: [...], total }
```
获取待处理的日程安排队列。

### `POST /api/schedule-queue/:id/approve`
批准队列中的日程请求并创建任务。

### `POST /api/schedule-queue/:id/reject`
```
Body: { reason? }
```
拒绝队列中的日程请求。
