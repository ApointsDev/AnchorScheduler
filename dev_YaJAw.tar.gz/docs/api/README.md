# API 文档

> **Base URL**: `https://schedule.apoints.cn`  
> **认证方式**: JWT Bearer Token（`Authorization: Bearer <token>`）

## 文档索引

| 文件 | 模块 | 端点数 |
|------|------|--------|
| [auth.md](auth.md) | 认证 / CAF / Exchange / IMAP | 10 |
| [user.md](user.md) | 用户 / 设置 / 操作日志 | 10 |
| [tasks.md](tasks.md) | 任务 CRUD / 日程队列 | 13 |
| [email.md](email.md) | 邮件列表 / 搜索 / AI 处理 | 5 |
| [chat.md](chat.md) | LLM 对话 / 聊天上下文 | 8 |
| [calendar.md](calendar.md) | CalDAV / 课表同步 | 12 |
| [admin.md](admin.md) | 管理后台 | 9 |
| [integrations.md](integrations.md) | 算法 / 豆包 / MCP / Ebridge / 分享 | 19 |
| [reference.md](reference.md) | 数据结构 / WebSocket / 状态码 | — |

## 认证说明

所有标注 🔒 的端点需要在请求头中携带 JWT：

```
Authorization: Bearer <your_jwt_token>
```

JWT 通过 `/login`、`/register`、`/api/auth/caf/token` 获取。

管理端点额外需要管理员白名单（标注 🛡）。

## 状态码约定

| 状态码 | 说明 |
|--------|------|
| 200 | 成功 |
| 201 | 创建成功 |
| 400 | 请求参数错误 |
| 401 | 未认证或 token 过期 |
| 403 | 无权限 |
| 404 | 资源不存在 |
| 409 | 冲突（如日程时间冲突） |
| 500 | 服务器内部错误 |
